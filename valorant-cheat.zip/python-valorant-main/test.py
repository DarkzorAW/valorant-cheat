import keyboard
import mouse

test69 = mouse.on_click(lambda: mouse.move(0, 500, absolute=False, duration=0.2))


#mouse.on_click(lambda: print("Left Button clicked."))

while True:  # making a loop
    try:  # used try so that if user pressed other than the given key error will not be shown
        if keyboard.is_pressed('f'):  # if key 'q' is pressed

            print('You Pressed A Key!')
            mouse.unhook_all()


            break  # finishing the loop
    except:
        break  # if user pressed a key other than the given key the loop will break
